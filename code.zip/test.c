//C:\\vs-c\\bianyiyuanli\\test.c


a = a *;


// double  d = 001;
// float   q = a + b;
// int     a = (a*(a+b)*(a+c)+(b+a)) / 2;
// //  efaedaedebdaedebdaedebbce#
// int (a) = (a*(a+b)*(a+c)+(b+a)) / 2;  
// int a = (a*(a+b)*(a+c)+(b+a) / 2;
// float   q /= 5 + b;
// float   q += a + 3;
// float   q += a + b >>= a ;
//         //e f e d e f e 
// float   q >>= a + b;
// int   q <<= a + b;  




