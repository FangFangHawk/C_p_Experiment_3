#include "Lexical_scanning.cpp"
#include "Syntactic_analysis.cpp"
#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <set>
#include<fstream>  //ifstream
#include <io.h>
#include <stack>
#include <queue>
#include <unordered_map>
using namespace std;

struct four_eles{
    string op;
    string ele_1;
    string ele_2;
    string ele_3;
};

//unordered_map<string , int> Sem_state_kinds;
unordered_map<string , vector<string> > Syn_G_sem;

void init_Sem(){
    // Sem_state_kinds["E"] = 1;
    // Sem_state_kinds["E*"] = 2;
    // Sem_state_kinds["T"] = 1;
    // Sem_state_kinds["T*"] = 3;
    // Sem_state_kinds["F"] = 1;
    // Sem_state_kinds["F*"] = 3;
    // Sem_state_kinds["R"] = 1;
    // Sem_state_kinds["R*"] = 3;
    // Sem_state_kinds["V"] = 2;
    Syn_G_sem["E1"] = {"E*" , "T"}; 

    Syn_G_sem["E*1"] = {"E*" , "GEQ(=)" , "T" , "="};
    Syn_G_sem["E*2"] = {"end"};

    Syn_G_sem["T1"] = {"T*" , "F"};

    Syn_G_sem["T*1"] = {"T*" , "GEQ(>)" , "F" , ">"};
    Syn_G_sem["T*2"] = {"T*" , "GEQ(<)" , "F" , "<"};
    Syn_G_sem["T*3"] = {"end"};

    Syn_G_sem["F1"] = {"F*" , "R"};

    Syn_G_sem["F*1"] = {"F*" , "GEQ(+)" , "R" , "+"};
    Syn_G_sem["F*2"] = {"F*" , "GEQ(-)" , "R" , "-"};
    Syn_G_sem["F*3"] = {"end"};

    Syn_G_sem["R1"] = {"R*" , "V"};

    Syn_G_sem["R*1"] = {"R*" , "GEQ(*)" , "V" , "*"};
    Syn_G_sem["R*2"] = {"R*" , "GEQ(/)" , "V" , "/"};
    Syn_G_sem["R*3"] = {"end"};

    Syn_G_sem["V1"] = {"pushi"};
    Syn_G_sem["V2"] = {")" , "E" , "("};
}

string Lex2Sem(int Lex_id){

    if(Lex_id >= 4 && Lex_id <= 36){
        return "n";
    }
    switch (Lex_id){
        case 0:
        case 3:
            return "i";        
        case 37:
            return "+";
        case 38:
            return "-";
        case 39:
            return "*";
        case 40:
            return "/";
        case 59:
            return "=";
        case 44:
            return ">";
        case 45:
            return "<";
        case 70:
            return "(";
        case 71:
            return ")";
        case 78:
            return "#";
    }    

    return "error";

}


int get_four_ele_str(int now_index , vector< pair<string , int> > now , queue<string>& LexId_q){

    while(now_index < now.size()){
        string c = Lex2Sem(now[now_index].second);
        now_index++;
        if(c == "n")
            continue;
        if(c == "#"){
            LexId_q.push(c);
            return now_index;
        }
        else if(c == "error"){
            cout<<c<<" "<<now[now_index].second<<" "<<now[now_index].first<<endl;
            return -1;
        }
        else if(c == "i"){
            LexId_q.push("*i*" + now[now_index-1].first);
            continue;
        }
        LexId_q.push(c);
    }
    return -1;    


}


vector<string> Sem_op(string now_state  , string now_c){
    vector<string> res;
    if(now_state == now_c){
        return {"allpop"};
    }
    // int kinds = Sem_state_kinds[now_state];
    // for(int i = 1 ; i <= kinds ; i++){
    //     string tmp = now_state + to_string(i);
    //     vector<string> now_tmp = Syn_G_sem[tmp];
    // }

    int op = -1;

    if(now_state == "E" || now_state == "T" || now_state == "F" || now_state == "R" ){
        //cout<<"asdasd"<<now_state <<now_c<<endl;
        if(now_c.size() > 3){
            if(now_c.substr(0,3) == "*i*"){
                op = 1;
            }
            else 
                return res;
        }
        else if(now_c == "("){
            op = 1;
        }
        else   
            return res;
    }
    else if(now_state == "E*"){
        if(now_c == "=")
            op = 1;
        else if(now_c == ")" || now_c == "#")
            op = 2;
        else
            return res;
    }
    else if(now_state == "T*"){
        if(now_c == "=" || now_c == ")" || now_c == "#")
            op = 3;
        else if(now_c == ">")
            op = 1;
        else if(now_c == "<")
            op =2;
        else
            return res;
    }
    else if(now_state == "F*"){
        if(now_c == "=" || now_c == ">" || now_c == "<" || now_c == ")" || now_c == "#")
            op = 3;
        else if(now_c == "+")
            op = 1;
        else if(now_c == "-")
            op =2;
        else
            return res;
    }
    else if(now_state == "R*"){
        if(now_c == "=" || now_c == "-"  || now_c == "+"  || now_c == ">" || now_c == "<" || now_c == ")" || now_c == "#")
            op = 3;
        else if(now_c == "*")
            op = 1;
        else if(now_c == "/")
            op =2;
        else
            return res;
    }
    else if(now_state == "V"){
        if(now_c.size() > 3){
            if(now_c.substr(0,3) == "*i*"){
                op = 1;
            }
            else 
                return res;
        }
        else if(now_c == "(")
            op = 2;
        else 
            return res;
    }
    string res_op = now_state + to_string(op);
    cout<<"the res_op is "<<res_op<<endl;
    cout<<Syn_G_sem[res_op].size()<<endl;
    return Syn_G_sem[res_op];

}
void show_QT(vector<four_eles> QT){
    int n = QT.size();
    for(int i = 1 ; i <= n ; i++){
        cout<<"(" << i <<") : "<< "( "<<QT[i-1].op<<QT[i-1].ele_1<<" , "<<QT[i-1].ele_2 <<" , "<<QT[i-1].ele_3<<" )"<<endl;
    }
}
void show(queue<string> LexId_q,stack<string> SYN,stack<string> SEM,vector<four_eles> QT){
    cout<<"LexId_q"<<endl;
    while(!LexId_q.empty()){
        cout<<LexId_q.front();
        LexId_q.pop();
    }
    cout<<endl;  
    cout<<"SYN"<<endl;
    while(!SYN.empty()){
        cout<<SYN.top()<<endl;
        SYN.pop();
    }
    cout<<endl;    
    cout<<"SEM"<<endl;
    while(!SEM.empty()){
        cout<<SEM.top()<<endl;
        SEM.pop();
    }
    cout<<endl;   

    cout<<"QT"<<endl;
    show_QT(QT);  
}


vector< vector<four_eles> > Sem_ana(vector< pair<string , int> > now){
    //init_Sem();
    vector< vector<four_eles> > err;
    vector< vector<four_eles> > right;
    // stack<string> SYN;
    // stack<string> SEM;
    int n = now.size();
    //起始栈

    //初始化

    int now_index = 0;
    int right_count = 0;
    while(now_index < n){
        right_count++;
        queue<string> LexId_q;
        stack<string> SYN;
        stack<string> SEM;
        vector<four_eles> QT;
        now_index = get_four_ele_str(now_index , now , LexId_q);
        if(now_index < 0){
            cout<<"error: the now_index < 0 (Incorrect symbol exists). line : "<<right_count<<endl;
            return err;
        }    
        // while(!LexId_q.empty()){
        //     cout<<LexId_q.front();
        //     LexId_q.pop();
        // }
        //cout<<endl;        
        SYN.push("#");
        SYN.push("E");
        int t_count = 1;
        while(!SYN.empty()){
            string now_state = SYN.top();
            SYN.pop();
            string now_c = LexId_q.front();
            //cout<<"asdad" <<now_state<<endl;

            if(now_state == "#" && now_c == "#"){
                cout<<"SUCCESS Finshed"<<endl;
                break;
            }

            if(now_state == "pushi"){
                SEM.push(now_c.substr(3 , now_c.size()));
                LexId_q.pop();
                continue;
            }
            else if(now_state == "end"){
                continue;
            }
            else if(now_state.size() > 5){
                if(now_state.substr(0,3) == "GEQ"){
                    four_eles now_four;  
                    if(SEM.size() < 2){
                        cout<<"error: the SEM.size() <2  (The number of saved elements is less than 2). line : "<<right_count<<endl;
                        return err;                        
                    } 
                    now_four.op = now_state[4]; 
                    now_four.ele_2 = SEM.top();
                    SEM.pop();
                    now_four.ele_1 = SEM.top();
                    SEM.pop();
                    now_four.ele_3 = "t" + to_string(t_count);
                    t_count++;
                    SEM.push(now_four.ele_3);
                    QT.push_back(now_four);
                    continue;
                }
            }




            vector<string> op_res = Sem_op(now_state , now_c);

            if(op_res.empty()){
                cout<<"error: the op_res == 0 (Unrecognized state). line : "<<right_count<<endl;
                show(LexId_q , SYN , SEM , QT);
                return err;
            }
            if(op_res[0] == "allpop"){
                LexId_q.pop();
                continue;
            }
            int op_res_size = op_res.size();
            for(int i = 0 ; i < op_res_size ; i++){
                SYN.push(op_res[i]);
            }

        }
        show_QT(QT);
        right.push_back(QT);
    }
    return right;

}



int main(){

    //获得词法分析之后的表格
    vector< pair<string , int> > now;
    now = Lexical_scanning();
    // int op = 0;
    // cout<<"plz input whitch you want to play:"<<endl;
    // cout<<"1 : LL(1)"<<endl;
    // cout<<"2 : LR"<<endl;
    // cin>>op;
    // if(op == 1){
    //     check_LL_1(now);
    // }
    // else if(op == 2){
    //     init_LR_map();
    //     check_SLR(now);
    // }
    // else{
    //     cout<<"error choice"<<endl;
    // }
    init_Sem();
    vector< vector<four_eles> > check = Sem_ana(now);
    
    if(check.size() == 0)
        cout<<"error"<<endl;
    cout<<"plz enter 1 to exit"<<endl;
    string a;
    cin>>a;
    return 0;


}